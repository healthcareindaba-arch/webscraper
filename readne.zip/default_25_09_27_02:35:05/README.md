# Google Scraper SaaS Project

## Project Overview
This project is a full-stack SaaS application that allows users to scrape Google search results programmatically. The backend is built with Node.js and Express, exposing an API endpoint to scrape Google search results. The frontend is a React application that provides an interface for users to enter search queries and specify the number of results, then displays the scraped data.

---

## Prerequisites

- Node.js (v14 or higher recommended)
- npm (comes with Node.js)
- Internet connection (to fetch Google search results)
- Optional: yarn (if you prefer it over npm)

---

## Folder Structure

