require('dotenv').config();
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const axios = require('axios');
const cheerio = require('cheerio');

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(bodyParser.json());

app.post('/api/scrape-google', async (req, res) => {
  try {
    const { query, numResults } = req.body;

    if (!query || typeof query !== 'string' || query.trim() === '') {
      return res.status(400).json({ error: 'Invalid or missing query parameter' });
    }

    const resultsCount = parseInt(numResults, 10);
    if (isNaN(resultsCount) || resultsCount <= 0) {
      return res.status(400).json({ error: 'Invalid or missing numResults parameter' });
    }

    // Google search URL with query encoded and numResults not directly supported in URL
    // We will scrape the first pages until we collect enough results
    // Google shows 10 results per page, so calculate pages needed
    const resultsPerPage = 10;
    const pagesNeeded = Math.ceil(resultsCount / resultsPerPage);

    let results = [];

    for (let page = 0; page < pagesNeeded; page++) {
      const start = page * resultsPerPage;
      const url = `https://www.google.com/search?q=${encodeURIComponent(query)}&start=${start}`;

      const { data: html } = await axios.get(url, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) ' +
            'AppleWebKit/537.36 (KHTML, like Gecko) ' +
            'Chrome/90.0.4430.93 Safari/537.36',
          Accept: 'text/html,application/xhtml+xml,application/xml',
        },
      });

      const $ = cheerio.load(html);

      // Selector to locate search results
      // Google frequently changes DOM structure, so selectors may need adjustment in future
      $('div.g').each((index, element) => {
        if (results.length >= resultsCount) {
          return false; // break out of each loop
        }
        const el = $(element);

        // Title
        const titleEl = el.find('h3');
        if (!titleEl.length) return;

        const title = titleEl.text();

        // URL
        let link = el.find('a').attr('href') || '';
        if (link.startsWith('/url?q=')) {
          link = link.replace('/url?q=', '').split('&')[0];
        }

        // Snippet
        const snippetEl = el.find('span.aCOpRe, div.IsZvec');
        let snippet = snippetEl.first().text().trim();

        if (!snippet) {
          snippet = el.find('div.VwiC3b').text().trim();
        }

        results.push({ title, link, snippet });
      });

      if (results.length >= resultsCount) {
        break;
      }
    }

    res.json({ results: results.slice(0, resultsCount) });
  } catch (error) {
    console.error('Error scraping Google:', error.message);
    res.status(500).json({ error: 'Failed to scrape Google search results' });
  }
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
