import React, { useState } from 'react';
import axios from 'axios';

const backendUrl = process.env.REACT_APP_BACKEND_URL || 'http://localhost:5000';

function App() {
  const [query, setQuery] = useState('');
  const [numResults, setNumResults] = useState(10);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [results, setResults] = useState([]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setResults([]);
    if (query.trim() === '') {
      setError('Please enter a search query.');
      return;
    }
    if (numResults <= 0 || isNaN(numResults)) {
      setError('Please enter a valid number of results.');
      return;
    }

    setLoading(true);

    try {
      const response = await axios.post(`${backendUrl}/api/scrape-google`, {
        query,
        numResults: Number(numResults),
      });

      if (response.data && Array.isArray(response.data.results)) {
        setResults(response.data.results);
      } else {
        setError('Unexpected response from server.');
      }
    } catch (err) {
      if (err.response && err.response.data && err.response.data.error) {
        setError(err.response.data.error);
      } else {
        setError('Failed to fetch results. Please try again later.');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={styles.container}>
      <h1 style={styles.title}>Google Scraper SaaS</h1>
      <form onSubmit={handleSubmit} style={styles.form}>
        <input
          type="text"
          placeholder="Enter search query"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          style={styles.input}
          required
        />
        <input
          type="number"
          min="1"
          max="100"
          value={numResults}
          onChange={(e) => setNumResults(e.target.value)}
          style={styles.inputSmall}
          required
        />
        <button type="submit" style={styles.button} disabled={loading}>
          {loading ? 'Searching...' : 'Search'}
        </button>
      </form>
      {error && <div style={styles.error}>{error}</div>}
      <div style={styles.resultsContainer}>
        {results.map((result, idx) => (
          <div key={idx} style={styles.resultItem}>
            <a href={result.link} target="_blank" rel="noopener noreferrer" style={styles.resultTitle}>
              {result.title}
            </a>
            <div style={styles.resultLink}>{result.link}</div>
            <p style={styles.resultSnippet}>{result.snippet}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

const styles = {
  container: {
    maxWidth: 800,
    margin: '2rem auto',
    padding: '0 1rem',
    fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
  },
  title: {
    textAlign: 'center',
    marginBottom: '1.5rem',
  },
  form: {
    display: 'flex',
    justifyContent: 'center',
    marginBottom: '1rem',
    gap: '0.5rem',
    flexWrap: 'wrap',
  },
  input: {
    flex: '1 1 300px',
    padding: '0.5rem',
    fontSize: '1rem',
  },
  inputSmall: {
    width: 80,
    padding: '0.5rem',
    fontSize: '1rem',
  },
  button: {
    padding: '0.5rem 1rem',
    fontSize: '1rem',
    cursor: 'pointer',
  },
  error: {
    color: 'red',
    textAlign: 'center',
    marginBottom: '1rem',
  },
  resultsContainer: {
    marginTop: '1rem',
  },
  resultItem: {
    marginBottom: '1.5rem',
    paddingBottom: '1rem',
    borderBottom: '1px solid #ccc',
  },
  resultTitle: {
    fontSize: '1.1rem',
    fontWeight: 'bold',
    color: '#1a0dab',
    textDecoration: 'none',
  },
  resultLink: {
    fontSize: '0.9rem',
    color: '#006621',
    marginBottom: '0.3rem',
  },
  resultSnippet: {
    fontSize: '1rem',
    color: '#545454',
  },
};

export default App;
